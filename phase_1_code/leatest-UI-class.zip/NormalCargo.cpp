#include "NormalCargo.h"
NormalCargo::NormalCargo(int ID, Time prep, int LD, int dd, int cost) :cargo(ID, prep, LD, dd, cost)
{

}
NormalCargo::~NormalCargo()
{
}
NormalCargo::NormalCargo()
{
}
