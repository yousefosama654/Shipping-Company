#include"cargo.h"
//#include"files.h"
void cargo::setrequest(bool x)
{
	requested = x;
}
bool cargo::checkloading()
{
	if (this->getStatus() == WAITING)
		return 0;
	return 1;

}
bool cargo::getrequest()
{
	return requested;
}
cargo::cargo() :WT(0), state(WAITING), MT(0), CDT(0),associated(nullptr)
{

}
cargo::cargo(int ID, Time Prep, int LD, int dd, int cost) //:maxWaitingTime(MW)
{
	setCost(cost);
	setId(ID);
	setDeliveryDistance(dd);
	setLoadingTime(LD);
	setPreparationTime(Prep);
}
void cargo:: setPreparationTime(Time prep)
{
	PT = prep;
}
void cargo::setCost(int c)
{
	cost = c;
}
void cargo:: setDeliveryDistance(int dd)
{
	deliveryDistance = dd;
}
void cargo::setLoadingTime(int x)
{
	loadingTime = x;
}
void cargo::setId(int ID)
{
	id = ID;
}
void cargo::setStatus(status s)
{
	state = s;
}
void cargo:: setassociated(truck* ass)
{
	this->associated=ass;
}
int cargo::getCost()
{
	return cost;
}
truck* cargo::getassociated()
{
	return this->associated;
}
Time cargo::getDeliverlyTime()
{
	return CDT;
}
int cargo:: getLoadingTime()
{
	return loadingTime;
}
int cargo:: getId()
{
	return id;
}
status cargo :: getStatus()
{
	return state;
}
