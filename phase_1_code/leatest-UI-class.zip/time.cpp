#include "Time.h"
#include <iostream>
using namespace std;
Time::Time(int d, int h)
{
	hour = h;
	day = h;
}
void Time::setday(int x)
{
	day = x > 0 ? x: 1;
}
void Time::sethour(int x)
{
	if (x > 23)
	{
		day++;
		hour = x - 24;
		return;
	}
	hour = x > 0 ? x : 0;
}
int Time :: gethour() 
{
	return hour;
}
int Time:: getday() 
{
	return day;
}

Time Time::operator+(const Time& t1)
{
	this->setday(this->day +t1.day); 
	this->sethour(this->hour + t1.hour);
	return *this;
}

Time Time::operator-(const Time& t1)
{
	this->sethour(this->hour - t1.hour);
	return *this;
}
