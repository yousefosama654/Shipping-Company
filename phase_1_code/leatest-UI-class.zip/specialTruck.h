#pragma once
#include "truck.h"
class specialTruck
	: public truck
{

};

