#include "Company.h"

void Company::PromoteCargo(int CargoID)
{
}

void Company::CancelCargo(int CargoID)
{
}

void Company::AddToVIPCargos(vipCargo*, float)
{
}

void Company::AddToNormalCargos(NormalCargo*)
{
}

void Company::AddToSpeacialCargos(SpecialCargo*)
{
}
