#pragma once
#include"Time.h"
#include "info.h"
//#include"truck.h"
//#include"files.h"
class truck;
class cargo
{
protected:
	Time PT;//
	int loadingTime;// 
	int deliveryDistance;//
	int id;//
	int cost; //
	status state;
	Time MT;
	Time WT;
	Time CDT;
	// add setters and getters for them
	truck* associated;
	bool requested; 	 // when the cargo is requested it is transformed fro waiting to moving 
	//const Time maxWaitingTime; 

public:
	cargo(); // default constructor
	cargo(int ID, Time Prep, int LD, int dd, int cost); //non-default constructor
	// getters
	truck* getassociated();
	int getCost();
	Time getDeliverlyTime();
	int getLoadingTime();
	int getId();
	status getStatus();
	bool getrequest();
	// add cargotype
// add maxw
// add attributes

	//function to check loading
	bool checkloading();

	//setters
	void setPreparationTime(Time);
	void setrequest(bool);
	void setCost(int c); 
	void setDeliveryDistance(int dd); 
	void setLoadingTime(int loadingTime); 
	void setId(int ID); 
	void setStatus(status s);
	void setassociated(truck* p);
	
};
