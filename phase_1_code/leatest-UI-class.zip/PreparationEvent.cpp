#include "PreparationEvent.h"
// Initializing constructor
PreparationEvent::PreparationEvent(Company* Com,Time PT,int ID, Time ET,priority Type,int DS, int CT, int LD) :event(ET, ID, Com)
{
    cargoType=Type;
    loadTime=LD;
    distance=DS;
    cost=CT;
	this->PT = PT;
}
void PreparationEvent::Execute()
{
	if (cargoType == VIP)
	{
		vipCargo* VC = new vipCargo(this->getCargoID(), PT, loadTime, distance, cost); // Create new vip Cargo
		Comp->AddToVIPCargos(VC, VC->getpriority()); // Add it to the list
		return;
	}
	else if (cargoType == NORMAL)
	{
		NormalCargo* NC = new NormalCargo(this->getCargoID(), PT, loadTime, distance, cost); // Create new normal Cargo
		Comp->AddToNormalCargos(NC); // Add it to the list
		return;
	}
	else
	{
		SpecialCargo* SC = new SpecialCargo(this->getCargoID(), PT, loadTime, distance, cost); // Create new special Cargo
		Comp->AddToSpeacialCargos(SC); // Add it to the list
		return;
	}
}

PreparationEvent::~PreparationEvent()
{

}
