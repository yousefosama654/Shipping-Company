#pragma once
#include<iostream>
#include "Node.h"
using namespace std;
template <typename T>
class queue
{
	Node<T>* front;
	Node<T>* rear;
public:
	queue()
	{
		front = nullptr;
		rear = nullptr;
	}
	bool Enqueue(const T& data)
	{
		if (isFull())
			return 0;
		Node<T>* Newnode = new Node<T>(data);
		if (isempty())
		{
			front = rear = Newnode;
		}
		else
			rear->setNext(Newnode);
		rear = Newnode;
	}
	bool Dequeue()
	{
		if (isempty())
			return 0;
		Node<T>* temp = front;
		front = front->getNext();
		temp = nullptr;
		delete temp;

	}
	bool isFull()
	{
		Node<T>* ptr = new Node<T>();
		return (!ptr);
	}
	bool isempty()
	{
		return(front == nullptr && rear == nullptr);
	}
	T top()
	{
		return front->getItem();

	}
	void traverse()
	{
		Node<T>* temp = front;
		while (temp)
		{
			cout << temp->getItem() << endl;
			temp = temp->getNext();
		}

	}

};