#ifndef _LINKEDLIST
#define _LINKEDLIST
#include "Node.h"
#include<iostream>
using namespace std;
template <typename T>
class LinkedList
{
private:
	Node<T>* Head;
public:


	LinkedList()
	{
		Head = nullptr;
	}
	LinkedList(const LinkedList& abag)
		// deep copy constructor
	{
		Node<T>* temp = abag.Head;
		if (!temp)
			Head = nullptr;
		else
			Head = new Node<T>(temp->getItem());
		temp = temp->getNext();
		Node<T>* self = Head;
		while (temp)
		{
			self = new Node<T>(temp->getItem());
			temp = temp->getNext();
		}
		self->setNext(nullptr);
	}
	~LinkedList()
	{
		DeleteAll();
	}

	void PrintList()	const
	{
		cout << "\nprinting list contents:\n\n";
		Node<T>* p = Head;

		while (p)
		{
			cout << "[ " << p->getItem() << " ]";
			cout << "--->";
			p = p->getNext();
		}
		cout << "NULL\n";
	}


	void InsertBeg(const T& data)
	{
		Node<T>* R = new Node<T>(data);
		R->setNext(Head);
		Head = R;

	}

	void DeleteAll()
	{
		Node<T>* P = Head;
		while (Head)
		{
			P = Head->getNext();
			delete Head;
			Head = P;
		}
	}

	void InsertEnd(const T& data) {


		if (Head == nullptr)
		{
			Head = new Node<T>(data);
			Head->setNext(nullptr);

		}

		else {

			Node<T>* current = Head;
			Node<T>* R;


			while (current->getNext()) {
				current = current->getNext();
			}
			R = new Node<T>(data);
			current->setNext(R);
			R->setNext(nullptr);

		}
	}

	bool Find(const T& Key) {

		Node<T>* current = Head;
		while (current) {
			if (current->getItem() == Key) {

				return 1;
			}
			else
				current = current->getNext();
		}
		return false;
	}

	int CountOccurance(const T& value) {

		if (!Head)
			return 0;
		int counter = 0;
		Node<T>* current = Head;

		while (current) {
			if (current->getItem() == value) {
				counter++;
			}
			current = current->getNext();
		}
		return counter;
	}

	//Deletes the first node in the list
	void DeleteFirst() {
		if (!Head)
			return;
		Node<T>* current = Head;
		Head = Head->getNext();
		delete(current);

	}


	//Deletes the last node in the list
	void DeleteLast() {
		if (!Head) {
			return;
		}
		if (!Head->getNext()) {
			delete Head;
			Head = nullptr;
			return;
		}
		Node<T>* current = Head;
		Node<T>* next = Head->getNext();
		while (next->getNext()) {
			next = next->getNext();
			current = current->getNext();
		}
		delete (next);
		current->setNext(nullptr);
	}

	//[6] DeleteNode
	//deletes the first node with the given value (if found) and returns true
	//if not found, returns false
	//Note: List is not sorted
	bool DeleteNode(const T& value) {
		if (!Head)
			return 0;
		if (Head->getItem() == value)
		{
			Node<T>* h = Head->getNext();
			delete(Head);
			Head = h;
			return 1;
		}
		Node<T>* current = Head;
		Node<T>* prev = Head;
		while (current) {
			if (current->getItem() == value)
			{
				prev->setNext(current->getNext());
				delete(current);
				return true;
			}
			else {
				prev = current;
				current = current->getNext();
			}
		}
	}

	//[7] DeleteNodes
	//deletes ALL node with the given value (if found) and returns true
	//if not found, returns false
	//Note: List is not sorted
	bool DeleteNodes(const T& value) {
		if (!Head)
			return 0;
		if (Head->getItem() == value)
			DeleteFirst();
		Node<T>* current = Head->getNext();
		Node<T>* prev = Head;
		int counter = 0;
		while (current) {
			if (current->getItem() == value)
			{
				prev->setNext(current->getNext());
				delete current;
				current = prev->getNext();
				counter++;
			}
			else
			{
				prev = current;
				current = current->getNext();
			}
		}
		return counter;
	}
	Node<T>* getHead()
	{
		return Head;
	}
	void printKth(int k)
	{
		Node<T>* temp = Head;
		int a = 1;
		while (temp)
		{
			if (k == a)
				cout << "the data is = " << temp->getItem();
			a++;
			temp = temp->getNext();
		}
	}
	Node<T>* getlast()
	{
		Node<T>* temp = Head;
		while (temp->getNext())
		{
			temp = temp->getNext();
		}
		return temp;
	}

	int  getlength()
	{
		if (!Head)
			return 0;
		Node<T>* temp = Head;
		int a = 1;
		while (temp)
		{
			temp = temp->getNext();
			a++;
		}
		return a - 1;
	}

	void Delete_Node_ptr(Node<T>* ptr)
	{
		Node<T>* temp1 = Head;
		while (temp1->getNext() != ptr)
		{
			temp1 = temp1->getNext();
		}
		temp1->setNext(ptr->getNext());
	}

};

#endif