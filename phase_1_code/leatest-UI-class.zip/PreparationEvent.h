#pragma once
#include "event.h"
#include "info.h"
#include "time.h"
#include "queue.h"
#include "cargo.h"
#include "truck.h"
#include"Company.h"
#include"SpecialCargo.h"
#include"vipCargo.h"
#include"truck.h"
//#include"specialTruck.h"
//#include"viptruck.h"
#include"NormalCargo.h"
//#include"files.h"
class PreparationEvent : public event
{
    priority cargoType;
    int loadTime; 
	Time PT;
    int distance; 
    int cost; 
public:
	// Initializing constructor
	PreparationEvent(Company* Com,Time PT, int ID, Time ET, priority Type, int DS, int CT, int lD);
	// Execute
	virtual void Execute();
	// Destructor
	~PreparationEvent(); 
};

