using namespace std;
int main()
{

}