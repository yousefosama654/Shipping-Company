#include "SpecialCargo.h"
SpecialCargo::SpecialCargo(int ID, Time prep, int LD, int dd, int cost) :cargo(ID, prep, LD, dd, cost)
{

}
SpecialCargo::~SpecialCargo()
{
}
SpecialCargo::SpecialCargo()
{
}
