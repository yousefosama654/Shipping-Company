#pragma once
#include <string>
#include <iostream>
#include "event.h"
#include "PreparationEvent.h"
#include "cancellationEvent.h"
#include "promotionEvent.h"
class UI
{
	/* Ui HAS a func recieves event  and we call it from the ready event */
	// number of trucks
	int noOfNT; 
	int noOfST;
	int noOfVT;
	// speeds
	int speedOfNT;
	int speedOfST;
	int speedOfVT;
	// capacities
	int capacityOfNT;
	int capacityOfST;
	int capacityOfVT;

	// checkup durations
	int durabilityOfNT;
	int durabilityOfST;
	int durabilityOfVT;
	
	// journys
	int journeyBeforeCheck;
	
	// auto promotion limit
	int autoPromotionLimit;
	// maximum waiting period 
	int maxWaiting;


public:
	//console default
	void input(event** events); 
	void output(); 
	//file 
	bool input(event** events,string fileName);
	// returns false if file is not found 
	bool output(std::string fileName);

};

