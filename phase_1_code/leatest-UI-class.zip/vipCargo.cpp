#include "vipCargo.h"
vipCargo::vipCargo()
{
}
float vipCargo::getpriority()
{
	return priority;
}
vipCargo::~vipCargo()
{
}
vipCargo::vipCargo(int ID, Time prep, int LD, int dd, int cost):cargo(ID, prep,LD,dd,cost),priority(0)
{
	
	
}
void vipCargo::setpriority()
{
	// what is the real equation ??
	//priority = float(cost) / (dd);

	// what if days can be concluded
	// (preparation day -current day)*24 + prapartion hour - current hour;
	/// another reason is the simulation

}



