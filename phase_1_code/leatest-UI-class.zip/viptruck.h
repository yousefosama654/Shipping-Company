#pragma once
#include "truck.h"
class viptruck :
    public truck
{
};

