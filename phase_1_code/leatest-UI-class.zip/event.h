#pragma once
#include "Time.h"
class Company;
//#include"Company.h"
class event
{
	int CargoID;
	//name edited
	Time EventTime; 
protected:
	Company* Comp;
public:
	//Constructor
	event (Time ET, int ID, Company*com);
	//EventTime
	void setEventTime(Time ET);
	Time getEventTime();
	//cargoID
	void setCargoID(int ID);
	int getCargoID();
	//Execute
	virtual void Execute() = 0;
	//Destructor
	virtual ~event();
		
};

