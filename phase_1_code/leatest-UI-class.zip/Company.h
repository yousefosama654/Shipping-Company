#pragma once
#include"NormalCargo.h"
#include"SpecialCargo.h"
#include"vipCargo.h"
class Company
{
	int x;
public:
	void PromoteCargo(int CargoID);
	void CancelCargo(int CargoID);
	void AddToVIPCargos(vipCargo*,float);
	void AddToNormalCargos(NormalCargo*); 
	void AddToSpeacialCargos(SpecialCargo*);
	

};
