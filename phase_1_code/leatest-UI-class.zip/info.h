#pragma once
enum priority
{
	NORMAL,
	VIP,
	Special
};
enum status
{
	DELIVERED,
	WAITING,
	MOVING
};
