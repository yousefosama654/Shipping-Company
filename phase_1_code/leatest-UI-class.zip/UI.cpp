#include "UI.h"
#include "global.h"
#include <iostream>
#include <fstream>
using namespace std;
// may change that to be passed by reference
void UI::input(event** events)
{
	cin >> noOfNT >> noOfST >> noOfVT; 
	cout << endl; 
	cin >> speedOfNT >> speedOfST >> speedOfVT;
	cout << endl; 
	cin >> capacityOfNT >> capacityOfST >> capacityOfVT; 
	cout << endl; 
	cin >> durabilityOfNT >> durabilityOfST>> durabilityOfVT>> journeyBeforeCheck; 
	cout << endl;
	cin >> autoPromotionLimit >> maxWaiting; 
	cout << endl; 
	int numberOfEvents; 
	cin >> numberOfEvents;
	events = new event * [numberOfEvents]; 
	for (int i = 0; i < numberOfEvents; i++)
	{
		char x; 
		cin >> x; 
		Time t;
		int id;
		switch (x)
		{
		case 'R': 
			char type; 
			int id,dist,loadingTime,cost;
			cin >> type;
			cin >> id >> dist >> loadingTime >> cost; 
			// create the event and assign it to events[i] 
			
			break; 
		case 'X':
			cin >> t >> id; 
			// create the event and assign it to events[i] 
			
			break; 
		case 'P':
			int extraMoney;
			cin >> t >> id >> extraMoney; 
			// create the event and assign it to events[i] 

			break;
		}; 
	}
	

}

void UI::output()
{
}

bool UI::input(event** events,string fileName)
{
	ifstream inputFile; 
	inputFile.open(fileName, ios::in);
	if (inputFile.is_open())
	{

	}
	else
	{
		
		return false; 
	}
	return true; 
}

bool UI::output(std::string fileName)
{
	return false;
}
