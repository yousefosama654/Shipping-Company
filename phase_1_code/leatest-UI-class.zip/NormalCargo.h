#pragma once
#include "cargo.h"
class NormalCargo : public cargo
{
public:
	NormalCargo();
	NormalCargo(int ID, Time prep, int LD, int dd, int cost);
	~NormalCargo();
};

